//
// ���ļ����� JavaTM Architecture for XML Binding (JAXB) ����ʵ�� v2.2.8-b130911.1802 ���ɵ�
// ����� <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �����±���Դģʽʱ, �Դ��ļ��������޸Ķ�����ʧ��
// ����ʱ��: 2020.12.14 ʱ�� 05:25:29 PM CST 
//


package com.rockwell.autosuite.mes.bo.im.transfervcats;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.rockwell.autosuite.mes.bo.im.transfervcats package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Eig_QNAME = new QName("", "Eig");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.rockwell.autosuite.mes.bo.im.transfervcats
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EigType }
     * 
     */
    public EigType createEigType() {
        return new EigType();
    }

    /**
     * Create an instance of {@link HeadType }
     * 
     */
    public HeadType createHeadType() {
        return new HeadType();
    }

    /**
     * Create an instance of {@link ItemsType }
     * 
     */
    public ItemsType createItemsType() {
        return new ItemsType();
    }

    /**
     * Create an instance of {@link VehicleType }
     * 
     */
    public VehicleType createVehicleType() {
        return new VehicleType();
    }

    /**
     * Create an instance of {@link ItemType }
     * 
     */
    public ItemType createItemType() {
        return new ItemType();
    }

    /**
     * Create an instance of {@link PartDataType }
     * 
     */
    public PartDataType createPartDataType() {
        return new PartDataType();
    }

    /**
     * Create an instance of {@link DATASType }
     * 
     */
    public DATASType createDATASType() {
        return new DATASType();
    }

    /**
     * Create an instance of {@link KeyPartType }
     * 
     */
    public KeyPartType createKeyPartType() {
        return new KeyPartType();
    }

    /**
     * Create an instance of {@link MeasurementItemType }
     * 
     */
    public MeasurementItemType createMeasurementItemType() {
        return new MeasurementItemType();
    }

    /**
     * Create an instance of {@link BroadcastDataType }
     * 
     */
    public BroadcastDataType createBroadcastDataType() {
        return new BroadcastDataType();
    }

    /**
     * Create an instance of {@link ProcessDataType }
     * 
     */
    public ProcessDataType createProcessDataType() {
        return new ProcessDataType();
    }

    /**
     * Create an instance of {@link DATAType }
     * 
     */
    public DATAType createDATAType() {
        return new DATAType();
    }

    /**
     * Create an instance of {@link RequestType }
     * 
     */
    public RequestType createRequestType() {
        return new RequestType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EigType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Eig")
    public JAXBElement<EigType> createEig(EigType value) {
        return new JAXBElement<EigType>(_Eig_QNAME, EigType.class, null, value);
    }

}
