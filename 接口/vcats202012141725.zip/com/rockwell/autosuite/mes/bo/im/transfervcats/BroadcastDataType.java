//
// ���ļ����� JavaTM Architecture for XML Binding (JAXB) ����ʵ�� v2.2.8-b130911.1802 ���ɵ�
// ����� <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �����±���Դģʽʱ, �Դ��ļ��������޸Ķ�����ʧ��
// ����ʱ��: 2020.12.14 ʱ�� 05:25:29 PM CST 
//


package com.rockwell.autosuite.mes.bo.im.transfervcats;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>BroadcastDataType complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="BroadcastDataType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="VIN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MODEYEAR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EOC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ECU" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BroadcastDataType", propOrder = {
    "vin",
    "modeyear",
    "sap",
    "eoc",
    "ecu"
})
public class BroadcastDataType {

    @XmlElement(name = "VIN", required = true)
    protected String vin;
    @XmlElement(name = "MODEYEAR", required = true)
    protected String modeyear;
    @XmlElement(name = "SAP", required = true)
    protected String sap;
    @XmlElement(name = "EOC", required = true)
    protected String eoc;
    @XmlElement(name = "ECU", required = true)
    protected String ecu;

    /**
     * ��ȡvin���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIN() {
        return vin;
    }

    /**
     * ����vin���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIN(String value) {
        this.vin = value;
    }

    /**
     * ��ȡmodeyear���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMODEYEAR() {
        return modeyear;
    }

    /**
     * ����modeyear���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMODEYEAR(String value) {
        this.modeyear = value;
    }

    /**
     * ��ȡsap���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAP() {
        return sap;
    }

    /**
     * ����sap���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAP(String value) {
        this.sap = value;
    }

    /**
     * ��ȡeoc���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEOC() {
        return eoc;
    }

    /**
     * ����eoc���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEOC(String value) {
        this.eoc = value;
    }

    /**
     * ��ȡecu���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getECU() {
        return ecu;
    }

    /**
     * ����ecu���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setECU(String value) {
        this.ecu = value;
    }

}
