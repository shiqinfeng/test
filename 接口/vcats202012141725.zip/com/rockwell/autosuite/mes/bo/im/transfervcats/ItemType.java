//
// ���ļ����� JavaTM Architecture for XML Binding (JAXB) ����ʵ�� v2.2.8-b130911.1802 ���ɵ�
// ����� <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �����±���Դģʽʱ, �Դ��ļ��������޸Ķ�����ʧ��
// ����ʱ��: 2020.12.14 ʱ�� 05:25:29 PM CST 
//


package com.rockwell.autosuite.mes.bo.im.transfervcats;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ItemType complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="ItemType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BroadcastData" type="{}BroadcastDataType" maxOccurs="50" minOccurs="0"/>
 *         &lt;element name="Vehicle" type="{}VehicleType" minOccurs="0"/>
 *         &lt;element name="Request" type="{}RequestType" maxOccurs="50" minOccurs="0"/>
 *         &lt;element name="ECUPartsData" type="{}PartDataType" maxOccurs="50" minOccurs="0"/>
 *         &lt;element name="ProcessData" type="{}ProcessDataType" minOccurs="0"/>
 *         &lt;element name="KeyPart" type="{}KeyPartType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemType", propOrder = {
    "broadcastData",
    "vehicle",
    "request",
    "ecuPartsData",
    "processData",
    "keyPart"
})
public class ItemType {

    @XmlElement(name = "BroadcastData")
    protected List<BroadcastDataType> broadcastData;
    @XmlElement(name = "Vehicle")
    protected VehicleType vehicle;
    @XmlElement(name = "Request")
    protected List<RequestType> request;
    @XmlElement(name = "ECUPartsData")
    protected List<PartDataType> ecuPartsData;
    @XmlElement(name = "ProcessData")
    protected ProcessDataType processData;
    @XmlElement(name = "KeyPart")
    protected KeyPartType keyPart;

    /**
     * Gets the value of the broadcastData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the broadcastData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBroadcastData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BroadcastDataType }
     * 
     * 
     */
    public List<BroadcastDataType> getBroadcastData() {
        if (broadcastData == null) {
            broadcastData = new ArrayList<BroadcastDataType>();
        }
        return this.broadcastData;
    }

    /**
     * ��ȡvehicle���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link VehicleType }
     *     
     */
    public VehicleType getVehicle() {
        return vehicle;
    }

    /**
     * ����vehicle���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link VehicleType }
     *     
     */
    public void setVehicle(VehicleType value) {
        this.vehicle = value;
    }

    /**
     * Gets the value of the request property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the request property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequest().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RequestType }
     * 
     * 
     */
    public List<RequestType> getRequest() {
        if (request == null) {
            request = new ArrayList<RequestType>();
        }
        return this.request;
    }

    /**
     * Gets the value of the ecuPartsData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ecuPartsData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getECUPartsData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartDataType }
     * 
     * 
     */
    public List<PartDataType> getECUPartsData() {
        if (ecuPartsData == null) {
            ecuPartsData = new ArrayList<PartDataType>();
        }
        return this.ecuPartsData;
    }

    /**
     * ��ȡprocessData���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link ProcessDataType }
     *     
     */
    public ProcessDataType getProcessData() {
        return processData;
    }

    /**
     * ����processData���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessDataType }
     *     
     */
    public void setProcessData(ProcessDataType value) {
        this.processData = value;
    }

    /**
     * ��ȡkeyPart���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link KeyPartType }
     *     
     */
    public KeyPartType getKeyPart() {
        return keyPart;
    }

    /**
     * ����keyPart���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link KeyPartType }
     *     
     */
    public void setKeyPart(KeyPartType value) {
        this.keyPart = value;
    }

}
