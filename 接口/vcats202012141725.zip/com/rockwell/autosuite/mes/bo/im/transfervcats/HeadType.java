//
// ���ļ����� JavaTM Architecture for XML Binding (JAXB) ����ʵ�� v2.2.8-b130911.1802 ���ɵ�
// ����� <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �����±���Դģʽʱ, �Դ��ļ��������޸Ķ�����ʧ��
// ����ʱ��: 2020.12.14 ʱ�� 05:25:29 PM CST 
//


package com.rockwell.autosuite.mes.bo.im.transfervcats;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>HeadType complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="HeadType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocType" type="{}messageType"/>
 *         &lt;element name="DocId" type="{}DocIdType"/>
 *         &lt;element name="DocNum" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="DocVersion" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="CreationTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="SourceSystem" type="{}sourceType"/>
 *         &lt;element name="RetryCount" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="DataCount" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="Test" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HeadType", propOrder = {
    "docType",
    "docId",
    "docNum",
    "docVersion",
    "creationTime",
    "sourceSystem",
    "retryCount",
    "dataCount",
    "test"
})
public class HeadType {

    @XmlElement(name = "DocType", required = true)
    @XmlSchemaType(name = "string")
    protected MessageType docType;
    @XmlElement(name = "DocId", required = true)
    protected String docId;
    @XmlElement(name = "DocNum", required = true)
    protected BigDecimal docNum;
    @XmlElement(name = "DocVersion", required = true)
    protected BigDecimal docVersion;
    @XmlElement(name = "CreationTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar creationTime;
    @XmlElement(name = "SourceSystem", required = true)
    @XmlSchemaType(name = "string")
    protected SourceType sourceSystem;
    @XmlElement(name = "RetryCount", required = true)
    protected BigInteger retryCount;
    @XmlElement(name = "DataCount", required = true)
    protected BigInteger dataCount;
    @XmlElement(name = "Test")
    protected boolean test;

    /**
     * ��ȡdocType���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link MessageType }
     *     
     */
    public MessageType getDocType() {
        return docType;
    }

    /**
     * ����docType���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link MessageType }
     *     
     */
    public void setDocType(MessageType value) {
        this.docType = value;
    }

    /**
     * ��ȡdocId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocId() {
        return docId;
    }

    /**
     * ����docId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocId(String value) {
        this.docId = value;
    }

    /**
     * ��ȡdocNum���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocNum() {
        return docNum;
    }

    /**
     * ����docNum���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocNum(BigDecimal value) {
        this.docNum = value;
    }

    /**
     * ��ȡdocVersion���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDocVersion() {
        return docVersion;
    }

    /**
     * ����docVersion���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDocVersion(BigDecimal value) {
        this.docVersion = value;
    }

    /**
     * ��ȡcreationTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreationTime() {
        return creationTime;
    }

    /**
     * ����creationTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreationTime(XMLGregorianCalendar value) {
        this.creationTime = value;
    }

    /**
     * ��ȡsourceSystem���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link SourceType }
     *     
     */
    public SourceType getSourceSystem() {
        return sourceSystem;
    }

    /**
     * ����sourceSystem���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link SourceType }
     *     
     */
    public void setSourceSystem(SourceType value) {
        this.sourceSystem = value;
    }

    /**
     * ��ȡretryCount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRetryCount() {
        return retryCount;
    }

    /**
     * ����retryCount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRetryCount(BigInteger value) {
        this.retryCount = value;
    }

    /**
     * ��ȡdataCount���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDataCount() {
        return dataCount;
    }

    /**
     * ����dataCount���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDataCount(BigInteger value) {
        this.dataCount = value;
    }

    /**
     * ��ȡtest���Ե�ֵ��
     * 
     */
    public boolean isTest() {
        return test;
    }

    /**
     * ����test���Ե�ֵ��
     * 
     */
    public void setTest(boolean value) {
        this.test = value;
    }

}
