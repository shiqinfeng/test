//
// ���ļ����� JavaTM Architecture for XML Binding (JAXB) ����ʵ�� v2.2.8-b130911.1802 ���ɵ�
// ����� <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// �����±���Դģʽʱ, �Դ��ļ��������޸Ķ�����ʧ��
// ����ʱ��: 2020.12.14 ʱ�� 05:25:29 PM CST 
//


package com.rockwell.autosuite.mes.bo.im.transfervcats;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>messageType�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * <p>
 * <pre>
 * &lt;simpleType name="messageType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Broadcast Data"/>
 *     &lt;enumeration value="ECU Key Part SN"/>
 *     &lt;enumeration value="Broadcast Request"/>
 *     &lt;enumeration value="ECU Part Code"/>
 *     &lt;enumeration value="Process Data"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "messageType")
@XmlEnum
public enum MessageType {

    @XmlEnumValue("Broadcast Data")
    BROADCAST_DATA("Broadcast Data"),
    @XmlEnumValue("ECU Key Part SN")
    ECU_KEY_PART_SN("ECU Key Part SN"),
    @XmlEnumValue("Broadcast Request")
    BROADCAST_REQUEST("Broadcast Request"),
    @XmlEnumValue("ECU Part Code")
    ECU_PART_CODE("ECU Part Code"),
    @XmlEnumValue("Process Data")
    PROCESS_DATA("Process Data");
    private final String value;

    MessageType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MessageType fromValue(String v) {
        for (MessageType c: MessageType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
